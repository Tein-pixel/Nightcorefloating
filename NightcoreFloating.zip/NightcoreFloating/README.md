# Nightcore Floating

Android project based on the supplied Nightcore Floating source.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK Platform 33 + Build-Tools.
3. Build > Build APK(s).

Debug APK is normally created at:
`app/build/outputs/apk/debug/app-debug.apk`

## Notes
- Overlay permission is required.
- The floating service runs as a foreground service on Android 8+.
- The project uses compileSdk/targetSdk 33 and minSdk 21.
- No external Android libraries are required by the app module.
