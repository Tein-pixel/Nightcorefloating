package com.nightcore.floating;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;

public class FloatingService extends Service {
    private static final String CHANNEL_ID = "nightcore_floating";
    private static final int NOTIFICATION_ID = 1;

    private WindowManager wm;
    private View bubbleView;
    private View resultView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams resultParams;

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;
    private TextRecognizer recognizer;

    private int screenW;
    private int screenH;
    private int densityDpi;
    private boolean capturing = false;
    private String scannedText = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        densityDpi = dm.densityDpi;

        createNotificationChannel();
        startForegroundCompat();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        setupBubble();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Nightcore Floating",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Notifikasi saat floating OCR aktif");
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Nightcore Floating")
                .setContentText("Floating OCR aktif")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
    }

    private void startForegroundCompat() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void setupBubble() {
        bubbleView = LayoutInflater.from(this).inflate(R.layout.floating_bubble, null);

        bubbleParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = Math.max(0, screenW - dp(70));
        bubbleParams.y = Math.max(0, screenH / 2);

        wm.addView(bubbleView, bubbleParams);

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            int initX;
            int initY;
            float touchX;
            float touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initX = bubbleParams.x;
                        initY = bubbleParams.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - touchX);
                        int dy = (int) (e.getRawY() - touchY);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;

                        bubbleParams.x = initX + dx;
                        bubbleParams.y = initY + dy;
                        clampBubble();
                        safeUpdate(bubbleView, bubbleParams);
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            captureScreen();
                        } else {
                            snapToEdge();
                        }
                        return true;

                    default:
                        return false;
                }
            }
        });
    }

    private void clampBubble() {
        int maxX = Math.max(0, screenW - dp(54));
        int maxY = Math.max(0, screenH - dp(54));
        bubbleParams.x = Math.max(-dp(20), Math.min(bubbleParams.x, maxX));
        bubbleParams.y = Math.max(0, Math.min(bubbleParams.y, maxY));
    }

    private void snapToEdge() {
        int edge = bubbleParams.x + dp(27) < screenW / 2 ? 0 : 1;
        bubbleParams.x = edge == 0 ? -dp(18) : screenW - dp(36);
        clampBubble();
        safeUpdate(bubbleView, bubbleParams);
    }

    private void captureScreen() {
        if (capturing) {
            Toast.makeText(this, "Sedang scan...", Toast.LENGTH_SHORT).show();
            return;
        }

        if (projection == null) {
            Toast.makeText(this, "Izin screen capture belum aktif", Toast.LENGTH_SHORT).show();
            return;
        }

        capturing = true;
        cleanupCaptureResources();

        try {
            reader = ImageReader.newInstance(
                    screenW,
                    screenH,
                    PixelFormat.RGBA_8888,
                    2
            );

            reader.setOnImageAvailableListener(r -> {
                Image img = null;
                Bitmap bmp = null;
                try {
                    img = r.acquireLatestImage();
                    if (img == null) return;

                    bmp = imageToBitmap(img);
                    if (bmp != null) runOcr(bmp);
                } catch (Exception e) {
                    capturing = false;
                    Toast.makeText(this, "Gagal mengambil layar", Toast.LENGTH_SHORT).show();
                    if (bmp != null) bmp.recycle();
                    cleanupCaptureResources();
                } finally {
                    if (img != null) img.close();
                }
            }, new Handler(Looper.getMainLooper()));

            display = projection.createVirtualDisplay(
                    "NightcoreFloating",
                    screenW,
                    screenH,
                    densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(),
                    null,
                    null
            );
        } catch (Exception e) {
            capturing = false;
            cleanupCaptureResources();
            Toast.makeText(this, "Screen capture gagal dimulai", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;

        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * screenW);
        int bitmapWidth = screenW + rowPadding / Math.max(1, pixelStride);

        Bitmap full = Bitmap.createBitmap(bitmapWidth, screenH, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        full.copyPixelsFromBuffer(buffer);

        Bitmap cropped = Bitmap.createBitmap(full, 0, 0, screenW, screenH);
        if (cropped != full) full.recycle();
        return cropped;
    }

    private void runOcr(Bitmap bmp) {
        if (recognizer == null) {
            capturing = false;
            bmp.recycle();
            return;
        }

        InputImage image = InputImage.fromBitmap(bmp, 0);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    scannedText = result.getText() == null ? "" : result.getText().trim();
                    showResult(scannedText);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "OCR gagal", Toast.LENGTH_SHORT).show()
                )
                .addOnCompleteListener(task -> {
                    capturing = false;
                    bmp.recycle();
                    cleanupCaptureResources();
                });
    }

    private void showResult(String text) {
        removeResultView();

        resultView = LayoutInflater.from(this).inflate(R.layout.floating_result, null);
        TextView txt = resultView.findViewById(R.id.txtScan);
        Button translate = resultView.findViewById(R.id.btnTranslate);
        Button gemini = resultView.findViewById(R.id.btnGemini);
        Button copy = resultView.findViewById(R.id.btnCopy);
        Button close = resultView.findViewById(R.id.btnCross);

        String safeText = text == null ? "" : text.trim();
        txt.setText(safeText.isEmpty() ? "Tidak ada teks terdeteksi" : safeText);

        if (safeText.isEmpty()) {
            translate.setEnabled(false);
            gemini.setEnabled(false);
            copy.setEnabled(false);
        }

        resultParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        resultParams.gravity = Gravity.CENTER;

        try {
            wm.addView(resultView, resultParams);
        } catch (Exception e) {
            resultView = null;
            return;
        }

        translate.setOnClickListener(v -> openTranslate(safeText));
        gemini.setOnClickListener(v -> openGemini(safeText));
        copy.setOnClickListener(v -> copyText(safeText));
        close.setOnClickListener(v -> removeResultView());
    }

    private void copyText(String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("Nightcore OCR", text));
            Toast.makeText(this, "Teks disalin", Toast.LENGTH_SHORT).show();
        }
    }

    private void openTranslate(String query) {
        openUrl("https://translate.google.com/?sl=auto&tl=id&text=" + Uri.encode(query));
    }

    private void openGemini(String query) {
        openUrl("https://gemini.google.com/app?q=" + Uri.encode(query));
    }

    private void openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi/browser yang bisa membuka link", Toast.LENGTH_SHORT).show();
        }
    }

    private void cleanupCaptureResources() {
        if (display != null) {
            try { display.release(); } catch (Exception ignored) { }
            display = null;
        }
        if (reader != null) {
            try { reader.close(); } catch (Exception ignored) { }
            reader = null;
        }
    }

    private void removeResultView() {
        if (resultView != null) {
            try { wm.removeView(resultView); } catch (Exception ignored) { }
            resultView = null;
        }
    }

    private void safeUpdate(View view, WindowManager.LayoutParams params) {
        if (view == null) return;
        try { wm.updateViewLayout(view, params); } catch (Exception ignored) { }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        removeResultView();
        cleanupCaptureResources();

        if (bubbleView != null) {
            try { wm.removeView(bubbleView); } catch (Exception ignored) { }
            bubbleView = null;
        }

        if (recognizer != null) {
            recognizer.close();
            recognizer = null;
        }

        if (projection != null) {
            try { projection.stop(); } catch (Exception ignored) { }
            projection = null;
        }

        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("data")) {
            int code = intent.getIntExtra("code", 0);
            Intent data = getProjectionIntent(intent);
            if (data != null) {
                MediaProjectionManager manager =
                        (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                if (manager != null) {
                    try {
                        projection = manager.getMediaProjection(code, data);
                    } catch (Exception e) {
                        Toast.makeText(this, "Izin screen capture tidak bisa dipakai", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
        return START_NOT_STICKY;
    }

    private Intent getProjectionIntent(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra("data", Intent.class);
        }
        return intent.getParcelableExtra("data");
    }
}
