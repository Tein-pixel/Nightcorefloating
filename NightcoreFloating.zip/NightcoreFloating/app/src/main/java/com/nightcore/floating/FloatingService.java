package com.nightcore.floating;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;

public class FloatingService extends Service {

    private static final String CHANNEL_ID = "nightcore_floating";
    private static final int NOTIFICATION_ID = 1001;

    private WindowManager wm;
    private View floatView;
    private WebView webView;
    private WindowManager.LayoutParams params;
    private boolean isCollapsed = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (floatView == null) onCreate();
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatView = LayoutInflater.from(this).inflate(R.layout.floating, null);
        webView = floatView.findViewById(R.id.webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setSupportZoom(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient());

        Button btnGoogle = floatView.findViewById(R.id.btnGoogle);
        Button btnAI = floatView.findViewById(R.id.btnAI);
        Button btnTranslate = floatView.findViewById(R.id.btnTranslate);
        Button btnGallery = floatView.findViewById(R.id.btnGallery);
        Button btnMin = floatView.findViewById(R.id.btnMinimize);
        Button btnClose = floatView.findViewById(R.id.btnClose);

        btnGoogle.setOnClickListener(v -> webView.loadUrl("https://www.google.com"));
        btnAI.setOnClickListener(v -> webView.loadUrl("https://gemini.google.com"));
        btnTranslate.setOnClickListener(v -> webView.loadUrl("https://translate.google.com"));
        btnGallery.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setType("image/*");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); } catch (Exception ignored) { }
        });
        btnMin.setOnClickListener(v -> {
            isCollapsed = !isCollapsed;
            webView.setVisibility(isCollapsed ? View.GONE : View.VISIBLE);
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            wm.updateViewLayout(floatView, params);
        });
        btnClose.setOnClickListener(v -> stopSelf());

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 50;
        params.y = 100;

        wm.addView(floatView, params);

        View dragBar = floatView.findViewById(R.id.dragBar);
        dragBar.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY;
            float initTouchX, initTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initX = params.x;
                        initY = params.y;
                        initTouchX = e.getRawX();
                        initTouchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initX + (int) (e.getRawX() - initTouchX);
                        params.y = initY + (int) (e.getRawY() - initTouchY);
                        wm.updateViewLayout(floatView, params);
                        return true;
                    default:
                        return false;
                }
            }
        });

        webView.loadUrl("https://www.google.com");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription(getString(R.string.channel_description));
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Nightcore Floating")
                    .setContentText("Floating window aktif")
                    .setSmallIcon(R.drawable.ic_launcher)
                    .setContentIntent(pendingIntent)
                    .setOngoing(true)
                    .build();
        }

        return new Notification.Builder(this)
                .setContentTitle("Nightcore Floating")
                .setContentText("Floating window aktif")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        if (floatView != null && wm != null) {
            try { wm.removeView(floatView); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
}
